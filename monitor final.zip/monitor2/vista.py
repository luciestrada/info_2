
from PyQt5.QtWidgets import QMainWindow, QDialog, QMessageBox, QApplication, QStackedWidget, QTableWidgetItem
from PyQt5.uic import loadUi
from PyQt5.QtGui import QStandardItemModel, QStandardItem

class Ventana(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi(r"C:\Users\lucia\Downloads\monitor2\VentanaLoguin.ui", self)
        self.setup()
        self.ventana_emergente = None
        self.__controlador = None
        self.__controlador_paciente = None  

    def setup(self):
        self.boton.clicked.connect(self.accion_ingresar)
        self.boton_salir.clicked.connect(self.salir_aplicacion)

    def asignarControlador(self, controlador, controlador_paciente):
        self.__controlador = controlador
        self.__controlador_paciente = controlador_paciente  

    def accion_ingresar(self):
        usuario = self.usuario.text()
        contrasena = self.contrasena.text()
        resultado = self.__controlador.validar_usuario(usuario, contrasena)
        
        if resultado:
            QMessageBox.information(self, "Resultado", "Usuario Valido")
            self.hide()
            if not self.ventana_emergente:
                self.ventana_emergente = VentanaEmergente()
                self.ventana_emergente.asignarControladorPaciente(self.__controlador_paciente)  
            self.ventana_emergente.show()
        else:
            QMessageBox.critical(self, "Resultado", "Usuario no Valido")

    def salir_aplicacion(self):
        respuesta = QMessageBox.question(self, 'Salir', '¿Estás seguro de que quieres salir?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if respuesta == QMessageBox.Yes:
            QApplication.quit()


class VentanaEmergente(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        loadUi(r"C:\Users\lucia\Downloads\monitor2\VentanaEmergente.ui", self)
        self.setWindowTitle("Ventana emergente")
        self.setup()

    def setup(self):

        self.agregar.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(2))
        self.buscar_2.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(1))
        self.eliminar_2.clicked.connect(self.mostrar_tabla_eliminar)
        self.salir1.clicked.connect(self.salir)

        self.pushbuscar.clicked.connect(self.buscar_paciente)
        self.pushagregar.clicked.connect(self.nuevo_paciente)
        self.pusheliminar.clicked.connect(self.eliminar_paciente)

    def asignarControladorPaciente(self, c):
        self.__controlador_paciente = c
    
    def tabla_actualizar(self):
        self.actualizar_tabla_pacientes()

    def nuevo_paciente(self):
        nombre = self.nombre.text().lower()
        apellido = self.apellido.text()
        edad = self.edad.text()
        id = self.id.text()
    
        if not id or not nombre or not edad or not id or not apellido:
            msgBox = QMessageBox()
            msgBox.setIcon(QMessageBox.Warning)
            msgBox.setText("Debe ingresar todos los datos")
            msgBox.setWindowTitle('Datos faltantes')
            msgBox.setStandardButtons(QMessageBox.Ok)
            msgBox.exec()
        else:
            paciente = {'Nombre': nombre, 'Apellido': apellido, 'Edad': edad, 'ID': id}
            isUnique = self.__controlador_paciente.paciente_nuevo(paciente)
            
            if not isUnique:
                msgBox = QMessageBox()
                msgBox.setIcon(QMessageBox.Warning)
                msgBox.setText("El ID ya existe")
                msgBox.setWindowTitle('ID repetido')
                msgBox.setStandardButtons(QMessageBox.Ok)
                msgBox.exec()
            else:
                self.tabla_actualizar()    
                self.id.setText('')
                self.nombre.setText('')
                self.apellido.setText('')
                self.edad.setText('')

                msgBox = QMessageBox()
                msgBox.setIcon(QMessageBox.Information)
                msgBox.setText("El paciente se ha agregado con éxito.")
                msgBox.setWindowTitle('Paciente agregado')
                msgBox.setStandardButtons(QMessageBox.Ok)
                msgBox.exec()

    def mostrar_paciente(self, paciente):
        tabla = self.tabla  
        tabla.setRowCount(0)
        fila = tabla.rowCount()
        tabla.insertRow(fila)

        tabla.setItem(fila, 0, QTableWidgetItem(paciente['Nombre']))
        tabla.setItem(fila, 1, QTableWidgetItem(paciente['Apellido']))
        tabla.setItem(fila, 2, QTableWidgetItem(paciente['Edad']))
        tabla.setItem(fila, 3, QTableWidgetItem(paciente['ID']))

    def buscar_paciente(self):
        nombre_paciente = self.busqueda.text().lower() 
        paciente = self.__controlador_paciente.buscar_paciente(nombre_paciente)

        if paciente:
            self.mostrar_paciente(paciente)
        else:
            msgBox = QMessageBox()
            msgBox.setIcon(QMessageBox.Warning)
            msgBox.setText("No se encontró ningún paciente con el Nombre proporcionado.")
            msgBox.setWindowTitle('Paciente no encontrado')
            msgBox.setStandardButtons(QMessageBox.Ok)
            msgBox.exec()

    def eliminar_paciente(self):
        nombre_paciente = self.busqueda_2.text().lower()  
        paciente_eliminado = self.__controlador_paciente.eliminar_paciente(nombre_paciente)

        if paciente_eliminado:
            self.actualizar_tabla_pacientes()  
            msgBox = QMessageBox()
            msgBox.setIcon(QMessageBox.Information)
            msgBox.setText("El paciente ha sido eliminado con éxito.")
            msgBox.setWindowTitle('Paciente eliminado')
            msgBox.setStandardButtons(QMessageBox.Ok)
            msgBox.exec()
        else:
            msgBox = QMessageBox()
            msgBox.setIcon(QMessageBox.Warning)
            msgBox.setText("No se encontró ningún paciente con el Nombre proporcionado.")
            msgBox.setWindowTitle('Paciente no encontrado')
            msgBox.setStandardButtons(QMessageBox.Ok)
            msgBox.exec()
    
    def mostrar_paciente_en_tabla(self, paciente):
        tabla = self.tabla_2  
        tabla.setRowCount(0)
        fila = tabla.rowCount()
    
        tabla.setItem(fila, 0, QTableWidgetItem(paciente['Nombre']))
        tabla.setItem(fila, 1, QTableWidgetItem(paciente['Apellido']))
        tabla.setItem(fila, 2, QTableWidgetItem(paciente['Edad']))
        tabla.setItem(fila, 3, QTableWidgetItem(paciente['ID']))

    def actualizar_tabla_pacientes(self):
        tabla = self.tabla_2  
        tabla.setRowCount(0)  

        pacientes = self.__controlador_paciente.modelo.pacientes  

        for paciente in pacientes:
            fila = tabla.rowCount()
            tabla.insertRow(fila)
            tabla.setItem(fila, 0, QTableWidgetItem(paciente['Nombre']))
            tabla.setItem(fila, 1, QTableWidgetItem(paciente['Apellido']))
            tabla.setItem(fila, 2, QTableWidgetItem(paciente['Edad']))
            tabla.setItem(fila, 3, QTableWidgetItem(paciente['ID']))

    def mostrar_tabla_eliminar(self):
        self.stackedWidget.setCurrentIndex(3)
        self.actualizar_tabla_pacientes()  

    def salir(self):
        respuesta = QMessageBox.question(self, 'Salir', '¿Estás seguro de que quieres salir?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if respuesta == QMessageBox.Yes:

            self.close()

            for widget in QApplication.topLevelWidgets():
                if isinstance(widget, Ventana):

                    widget.showNormal()
                    widget.activateWindow()
                    return

            ventana = Ventana()
            ventana.show()