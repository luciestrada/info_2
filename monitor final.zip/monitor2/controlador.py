
from modelo import Modelo, ModeloPaciente
from vista import Ventana
from PyQt5.QtWidgets import QApplication
import sys

class Controlador(object):
    def __init__(self, modelo):
        self.__mi_modelo = modelo

    def validar_usuario(self, u, p):
        return self.__mi_modelo.verificarUsuario(u, p)


class ControladorPaciente(object):
    def __init__(self, modelo):
        self.modelo = modelo

    def paciente_nuevo(self, data: dict):
        return self.modelo.agregar_paciente(data)

    def buscar_paciente(self, nombre):
        return self.modelo.buscar_paciente(nombre)
    
    def eliminar_paciente(self,nombre):
        return self.modelo.eliminar_paciente(nombre)

class Principal(object):
    def __init__(self):
        self.__app = QApplication(sys.argv)
        self.__mi_vista = Ventana()
        self.__mi_modelo = Modelo()
        self.__mi_modelo_paciente = ModeloPaciente('pacientes.csv') 
        self.__mi_modelo_paciente.cargar_datos() 
        self.__mi_controlador = Controlador(self.__mi_modelo)
        self.__mi_controlador_paciente = ControladorPaciente(self.__mi_modelo_paciente) 
        self.__mi_vista.asignarControlador(self.__mi_controlador, self.__mi_controlador_paciente)

    def main(self):
        self.__mi_vista.show()
        sys.exit(self.__app.exec_())

if __name__ == "__main__":
    p = Principal()
    p.main()
