import csv

class Modelo(object):
    def __init__(self):
        self.__usuarios = {}
        self.__usuarios['contrasena123'] = 'admin123'
        self.__usuarios['admin'] = 'admin'

    def verificarUsuario(self, u, p):
        try:
            if self.__usuarios[p] == u:
                return True
            else:
                return False
        except KeyError:
            return False

class ModeloPaciente(object):
    def __init__(self, csv_file):
        self.csv_file = csv_file
        self.pacientes = []

    def cargar_datos(self):
        with open(self.csv_file, 'r') as file:
            reader = csv.DictReader(file)
            self.pacientes = list(reader)

    def guardar_datos(self):
        with open(self.csv_file, 'w', newline='') as file:
            fieldnames = ['Nombre', 'Apellido', 'Edad', 'ID']
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(self.pacientes)

    def agregar_paciente(self, paciente: dict):
        if not any(p['ID'] == paciente['ID'] for p in self.pacientes):
            self.pacientes.append(paciente)
            self.guardar_datos()
            return True
        return False
    
    def buscar_paciente(self, nombre):
        for paciente in self.pacientes:
            if paciente['Nombre'] == nombre:
                return paciente  
        return None  
    
    def eliminar_paciente(self, nombre):
            for paciente in self.pacientes:
                if paciente['Nombre'].lower() == nombre.lower():
                    self.pacientes.remove(paciente)
                    self.guardar_datos()
                    return paciente  
            return None 
    


